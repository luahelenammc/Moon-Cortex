<!-- SPDX-FileCopyrightText: 2026 Lua Helena Moon Martins Cardoso (Moon) -->
<!-- SPDX-License-Identifier: CC-BY-4.0 -->

# Synthetic Example A · Simple Salaried User

**Status:** hypothetical / fictional / didactic / non-evidentiary  
**Module:** Moon Cortex · Financial Living System `0.1.0-pre.4`  
**Bootstrap:** Adaptive Finance Bootstrap  
**MSL:** 5.1

This example demonstrates that the bootstrap can stay small. It is not a case study and does not represent a real person.

## Field supplied

The fictional user says:

- one regular salary arrives once per month;
- all financial activity uses one currency;
- money lives in one current account and one savings account;
- there are housing, food, transport and subscription obligations;
- there are no credit cards, loans or installment purchases;
- the main problem is not knowing how much operating money remains after fixed obligations;
- savings contain a protected emergency amount and a flexible amount.

No current jurisdiction-specific rule is needed for the first setup.

## Field model

- **Income:** regular monthly, confirmed when received;
- **Cash:** one operating account plus one savings container;
- **Credit/debt:** none detected;
- **Obligations:** recurring and current-cycle;
- **Shared money:** none material;
- **Reserves:** protected emergency reserve and flexible savings;
- **Rhythm:** calendar-month cycle with recurring due dates;
- **Host:** persistent project source with reliable readback;
- **Main friction:** operating cash is confused with money already committed to obligations.

## Compiled capabilities

Activated:

- Financial Reality Gate;
- Current Financial State;
- Cycle Reconciliation;
- Reserve Semantics;
- Double-Count Guards;
- Cycle Closing and Carryover;
- Epistemic Typing.

Not activated:

- Credit Card Intelligence;
- Installment Tail Engine;
- Microfrequency / Swarm Analysis;
- Third-Party and Reimbursement Ledger;
- Multi-Currency Layer;
- Irregular Income Layer.

The bootstrap does not hand this user a credit-card dashboard simply because the dashboard exists. A rare victory for restraint.

## Installation profile

`compact_source_system` is sufficient:

- Finance Protocol;
- Current Financial State;
- Active Cycle;
- History.

A full specialized-ledger tree would add maintenance without adding a current capability.

## Expected local behavior

When the salary arrives, the local system records confirmed cash. It then marks the portion assigned to recurring obligations and the protected emergency reserve. Only the remainder is operating cash.

Moving money from the current account to savings is an internal transfer. It is not new income or spending.

At cycle close, the system reconciles opening cash, salary, paid obligations, transfers and closing cash, then carries only open commitments into the next cycle.

## Proportional reality check

The system passes this example if it:

- excludes the protected emergency reserve from free operating cash;
- does not invent card or installment machinery;
- does not count the current-to-savings transfer as an expense;
- identifies an unresolved difference instead of forcing the closing equation if a receipt is missing;
- produces a compact source system the user can actually maintain.

## Update trigger

Review the installation if the user adds credit, irregular income, shared expenses, another currency, a second material income rhythm or a host with different persistence limits.

<!-- MOON-CORTEX-PUBLIC-STAMP -->

---

> 🌙 **Moon Cortex · Financial Living System** · created by **Lua Helena Moon Martins Cardoso (Moon)** with AI-assisted coauthorial development by **Áurion** · instantiated through **Adaptive Finance Bootstrap** · [Licensing](https://github.com/luahelenammc/Moon-Cortex/blob/main/LICENSING.md) · [Moon Source bridge](https://github.com/luahelenammc/Moon-Source) · [Professional context](https://www.luahelena.com.br/ia/?lang=en) · [Full source (.zip)](https://github.com/luahelenammc/Moon-Cortex/archive/refs/heads/main.zip) · Questions, suggestions, or proposals? Feel free to contact me at [LuaHelenaMMC@gmail.com](mailto:LuaHelenaMMC@gmail.com).
