<!-- SPDX-FileCopyrightText: 2026 Lua Helena Moon Martins Cardoso (Moon) -->
<!-- SPDX-License-Identifier: CC-BY-4.0 -->

# Moon Source Installation Bridge

**Module:** Moon Cortex · Financial Living System  
**Bootstrap:** Adaptive Finance Bootstrap  
**Version:** `0.1.0-pre.4`  
**MSL:** 5.1  
**Bridge status:** public specification

## The boundary

```text
Moon Cortex · Financial Living System
defines the finance module identity
        ↓ instantiated through
Adaptive Finance Bootstrap
discovers and compiles the user's financial field
        ↓ optional installation governance
Moon Source
contributes current public context-architecture methods
        ↓
user-local living financial system
owns operational runtime after installation
```

Canonical sentence:

> **Moon Cortex defines the Financial Living System. The Adaptive Finance Bootstrap instantiates it from the user's field. Moon Source can govern installation context. The resulting local system belongs operationally to the user.**

## Transport, installation and runtime

### Transport

The canonical transport unit is the complete Financial Living System package. `ADAPTIVE_FINANCE_BOOTSTRAP.md` is the entry interface inside that package, while the companion files remain available as cooperating contracts. The package does not require the Moon Source repository to begin discovery or finish the Financial Field Model. An isolated bootstrap file is not the canonical Financial Living System transport.

### Installation

A Moon Source-aware completed installation requires current access to the public [`luahelenammc/Moon-Source`](https://github.com/luahelenammc/Moon-Source) repository. The current public method is part of the installation boundary, not a private corpus embedded into this module.

### Runtime

After installation, the generated user-local financial system operates from its own local sources. Routine transaction logging, reconciliation and cycle updates do not fetch Moon Source on every invocation.

## Installation gate

The executing AI must:

1. resolve the current public Moon Source repository and branch or release being used;
2. read `MOON_SOURCE_AI_KERNEL.md` first;
3. read `README.md` for orientation;
4. identify the financial field, host and local responsibility that require materialization;
5. load only the smallest relevant current public methods;
6. avoid recursive whole-repository ingestion;
7. resolve the local form and authority boundaries;
8. materialize or integrate the user's local financial system;
9. read the authoritative destination back;
10. run the proportional Financial Reality Test;
11. report the exact installation state, sources used, validation and remaining uncertainty.

The write is not complete merely because a connector returns success. Readback closes the mutation.

## Route by need

| Installation question | Smallest Moon Source route |
|---|---|
| How should the task be shaped before building? | `https://github.com/luahelenammc/Moon-Source/blob/main/portables/preflight/PREFLIGHT_V2.md` when the task is materially ambiguous or risky |
| What form should the field receive? | `docs/FIELD_TO_FORM.md` |
| Which source owns which responsibility? | `docs/RESPONSIBILITY_MAP.md` |
| How should connected sources, authority and readback be handled? | `docs/CONNECTED_SOURCES.md` |
| How should mutation, failure and receipts be bounded? | `docs/OPERATIONAL_RELIABILITY.md` |
| How should MSL 5.1 materialization be shaped? | `https://github.com/luahelenammc/Moon-Source/blob/main/portables/msl/MSL_5_1.md` |
| How should portable identity and adaptation be preserved? | `docs/PORTABLE_DESIGN_CONTRACT.md` plus `docs/CREDITS_ATTRIBUTION_OPS.md` when material |
| How should current public licensing and claims be checked? | `LICENSING.md`, `PUBLIC_BOUNDARY.md` and `EVIDENCE_AND_CLAIMS.md` |

The list is a router, not a command to load every file.

## Connected-source rules

The installer must preserve these distinctions:

- access is not authority;
- retrieval is not instruction authority;
- connection is not jurisdiction;
- search is discovery, not census;
- write capability is not mutation authority;
- write success is not source acceptance;
- fresh current source beats a stale snapshot when the current source governs;
- Drive, GitHub or another connector is a surface, not the financial ontology.

When semantic state lives in a document and executable state lives in a repository, authority may be federated by facet. Resolve the relevant source for the relevant claim instead of deciding that one vendor always wins.

## Missing Moon Source access

If the current public repository cannot be retrieved, finish everything that does not require it:

- setup and financial discovery;
- Financial Field Model;
- local lexicon;
- capability compilation;
- host and installation profile;
- installation-ready packet.

Use:

```text
setup_status = complete
financial_model_status = compiled
installation_status = ready_for_installation
moon_source_aware_installation_complete = false
```

State exactly what must be resumed after access is restored. Never claim to have consulted current Moon Source from memory.

## Installation profiles

### Full living workspace

Recommend when the host supports persistent multi-file sources, search, mutation and readback. Preserve responsibilities for stable rules, executive present, active cycle, optional ledgers and closed history.

### Compact source system

Use a protocol, current state, active cycle and history when the host is smaller but still persistent.

### Minimal single source

Use one carefully sectioned living source when the host cannot support multiple sources. State the weaker authority and archive guarantees. Do not pretend one file has federated jurisdiction.

### Existing-system integration

Inspect the user's system, map equivalent responsibilities, preserve sound local names and add only missing finance capabilities.

## Local sovereignty test

Installation is complete only if a later routine finance event can be handled from the user's local sources without retrieving Moon Source for ordinary runtime. Moon Source remains a justified rebase/repair/refresh dependency, not a permanent upstream API.

## Bridge attribution

This bridge uses public Moon Source methods as related installation lineage. It is part of Moon Cortex · Financial Living System and does not claim that Moon Source owns, endorses, validates or adopts the module.

Canonical public references:

- https://github.com/luahelenammc/Moon-Source
- https://www.luahelena.com.br/moonsource/?lang=en
- https://www.luahelena.com.br/ia/?lang=en

<!-- MOON-CORTEX-PUBLIC-STAMP -->

---

> 🌙 **Moon Cortex · Financial Living System** · created by **Lua Helena Moon Martins Cardoso (Moon)** with AI-assisted coauthorial development by **Áurion** · instantiated through **Adaptive Finance Bootstrap** · [Licensing](https://github.com/luahelenammc/Moon-Cortex/blob/main/LICENSING.md) · [Moon Source bridge](https://github.com/luahelenammc/Moon-Source) · [Professional context](https://www.luahelena.com.br/ia/?lang=en) · [Full source (.zip)](https://github.com/luahelenammc/Moon-Cortex/archive/refs/heads/main.zip) · Questions, suggestions, or proposals? Feel free to contact me at [LuaHelenaMMC@gmail.com](mailto:LuaHelenaMMC@gmail.com).
