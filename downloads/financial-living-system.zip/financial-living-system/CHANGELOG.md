<!-- SPDX-FileCopyrightText: 2026 Lua Helena Moon Martins Cardoso (Moon) -->
<!-- SPDX-License-Identifier: CC-BY-4.0 -->

# Financial Living System Changelog

## Unreleased — 2026-09-08

- embedded human and AI first-use onboarding in `ADAPTIVE_FINANCE_BOOTSTRAP.md`;
- retired the redundant module README while preserving the complete composite package and proportional internal attention;
- made no semantic version bump: onboarding integration changes the entry/package bytes but not the finance contract.

## 0.1.0-pre.4 — 2026-09-01

Package-integrity clarification.

- established the complete Financial Living System ZIP as the canonical transport and default use surface;
- clarified that internal Markdown files cooperate as one module and are not separate installation choices;
- retained the Adaptive Finance Bootstrap as the entrypoint inside the package;
- removed the prior standalone-bootstrap execution contract;
- preserved proportional internal loading, adaptive capability activation, optional Moon Source-aware installation and locally sovereign runtime.

## 0.1.0-pre.3 — 2026-09-01

Canonical product namespace and public-entrypoint release.

- moved the module to `modules/financial-living-system/` so the directory names the product rather than the bootstrap mechanism;
- renamed the canonical instantiation artifact to `ADAPTIVE_FINANCE_BOOTSTRAP.md`;
- rebuilt this README as a problem-first entrypoint with a one-minute architecture, adaptive-start route, examples, evidence boundaries and repository map;
- added a complete downloadable module archive at `downloads/financial-living-system.zip`;
- kept the Adaptive Finance Bootstrap self-activating and preserved all existing financial invariants, capability routing and installation-state semantics.

## 0.1.0-pre.2 — 2026-09-01

Public identity and editorial architecture patch.

- promoted **Financial Living System** as the module/product identity;
- named **Adaptive Finance Bootstrap** as the generative setup and instantiation mechanism;
- retained `FINANCE_BOOTSTRAP_SEED.md` as the stable canonical bootstrap path rather than renaming links for cosmetic consistency;
- clarified standalone setup, Moon Source-aware installation and user-local runtime sovereignty;
- removed publication/sanitization workflow residue from the user-facing public layer while preserving real privacy and claim safeguards;
- standardized the Moon Cortex public credits/attribution stamp;
- preserved adaptive jurisdiction discovery, `field before form`, `access ≠ activation`, existing-system integration and automatic activation.

## 0.1.0-pre.1 — 2026-09-01

First public portable release.

- documented reusable financial invariants for the Financial Living System;
- added adaptive jurisdiction, topology, temporal-rhythm, behavioral and host discovery;
- added need-based capability compilation with explicit `access ≠ activation` behavior;
- added Moon Source-aware canonical installation bridge and local-runtime sovereignty;
- added four proportional installation profiles;
- added privacy, attribution, claims and Financial Reality Test contracts;
- added three fictional synthetic examples;
- kept the canonical implementation model-agnostic and independent of a `SKILL.md` adapter.

<!-- MOON-CORTEX-PUBLIC-STAMP -->

---

> 🌙 **Moon Cortex · Financial Living System** · created by **Lua Helena Moon Martins Cardoso (Moon)** with AI-assisted coauthorial development by **Áurion** · instantiated through **Adaptive Finance Bootstrap** · [Licensing](https://github.com/luahelenammc/Moon-Cortex/blob/main/LICENSING.md) · [Moon Source bridge](https://github.com/luahelenammc/Moon-Source) · [Professional context](https://www.luahelena.com.br/ia/?lang=en) · [Full source (.zip)](https://github.com/luahelenammc/Moon-Cortex/archive/refs/heads/main.zip) · Questions, suggestions, or proposals? Feel free to contact me at [LuaHelenaMMC@gmail.com](mailto:LuaHelenaMMC@gmail.com).
