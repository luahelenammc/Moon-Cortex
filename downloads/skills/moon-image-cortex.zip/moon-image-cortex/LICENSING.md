<!-- SPDX-FileCopyrightText: 2026 Lua Helena Moon Martins Cardoso (Moon) -->
<!-- SPDX-License-Identifier: CC-BY-4.0 -->

# Moon Cortex Licensing

## License map for the current public pre-release

This repository contains documentation, methods, public portables, examples, textual specifications and a small validation automation layer. Moon-authored documentation and knowledge files are offered under the **Creative Commons Attribution 4.0 International** license (`CC-BY-4.0`), while validation scripts and GitHub workflows are offered under the **Apache License 2.0** (`Apache-2.0`), subject to any file-level or third-party notice.

The standard license text is included at [`LICENSES/CC-BY-4.0.txt`](LICENSES/CC-BY-4.0.txt), and the canonical license URI is:

https://creativecommons.org/licenses/by/4.0/

Validation scripts under `scripts/**` and workflows under `.github/workflows/**` are technical automation and use Apache-2.0. Documentation and software remain separate license layers; the addition of a guard does not change the license of the module content or public portables.

## Attribution

When sharing or adapting a material part of this repository, identify:

- the relevant module or **Moon Cortex** repository body;
- **Lua Helena Moon Martins Cardoso (Moon)** as creator;
- AI-assisted coauthorial development by **Áurion** as a process disclosure, not a transfer of human authorship;
- the canonical source path where practical;
- the applicable CC BY 4.0 license;
- the fact and nature of material changes.

### Financial Living System example

> Adapted from **Moon Cortex · Financial Living System**, instantiated through the **Adaptive Finance Bootstrap**, by Lua Helena Moon Martins Cardoso (Moon), with AI-assisted coauthorial development by Áurion. Local adaptation by **[project/person]**, **[version/date]**. Original module path: `luahelenammc/Moon-Cortex/modules/financial-living-system/`. Licensed under CC BY 4.0.

### Social Support Navigation System example

> Adapted from **Moon Cortex · Social Support Navigation System**, by Lua Helena Moon Martins Cardoso (Moon), with AI-assisted coauthorial development by Áurion. Local adaptation by **[project/person]**, **[version/date]**. Original module path: `luahelenammc/Moon-Cortex/modules/social-support-navigation-system/`. Licensed under CC BY 4.0.

### Probability Calibration System example

> Adapted from **Moon Cortex · Probability Calibration System**, by Lua Helena Moon Martins Cardoso (Moon), with AI-assisted coauthorial development by Áurion. Local adaptation by **[project/person]**, **[version/date]**. Original module path: luahelenammc/Moon-Cortex/modules/probability-calibration-system/. Licensed under CC BY 4.0.

### Moon Image Cortex example

> Adapted from **Moon Cortex · Moon Image Cortex**, by Lua Helena Moon Martins Cardoso (Moon), with AI-assisted coauthorial development by Áurion. Local adaptation by **[project/person]**, **[version/date]**. Original module path: luahelenammc/Moon-Cortex/modules/moon-image-cortex/. Licensed under CC BY 4.0.

The modules document independent interfaces and user-local data handling; permission for source material remains governed by its applicable license and the user's authorization.

Attribution does not imply endorsement, partnership, certification, adoption, professional licensure or validation by Moon.

## Compact public stamp

Tracked public Markdown documents in the repository use a compact identity footer. Its purpose is orientation and lineage continuity, not legal boilerplate.

### Root stamp

> 🌙 **Moon Cortex** · created by **Lua Helena Moon Martins Cardoso (Moon)** with AI-assisted coauthorial development by **Áurion** · [Licensing](https://github.com/luahelenammc/Moon-Cortex/blob/main/LICENSING.md) · [Moon Source bridge](https://github.com/luahelenammc/Moon-Source) · [Professional context](https://www.luahelena.com.br/ia/?lang=en) · Questions, suggestions, or proposals? Feel free to contact me at [LuaHelenaMMC@gmail.com](mailto:LuaHelenaMMC@gmail.com).

### Financial Living System stamp

The finance module retains its module-specific identity and portable link.

### Social Support Navigation System stamp

The social module retains its module-specific identity and portable link.

### Probability Calibration System stamp

The probability module retains its module-specific identity and portable link.

### Moon Image Cortex stamp

The visual module retains its module-specific identity and portable link.

Module-specific stamps point to module-specific portables. The repository should not gain a repository-wide distribution package merely because it contains multiple modules.

## Repository relationships

[Moon Source](https://github.com/luahelenammc/Moon-Source) is a separate public context-architecture project. It does not own or license the independent Cortex modules. Use the applicable license for the material actually reused; retain material third-party attributions and notices.

## Third-party material

The standard CC BY 4.0 text is reproduced for clarity and remains governed by its own public-license terms. External names, URLs and referenced standards remain subject to their own terms. Moon Image Cortex records artistic reference credits in its attribution document; the references are not reproduced assets, prompts, layouts, or evidence of permission. No third-party code, image, dataset or embedded media is intentionally incorporated in this release.

This file is project documentation, not legal advice. The applicable license text and law govern.

<!-- MOON-CORTEX-PUBLIC-STAMP -->

---

> 🌙 **Moon Cortex** · created by **Lua Helena Moon Martins Cardoso (Moon)** with AI-assisted coauthorial development by **Áurion** · [Licensing](https://github.com/luahelenammc/Moon-Cortex/blob/main/LICENSING.md) · [Moon Source bridge](https://github.com/luahelenammc/Moon-Source) · [Professional context](https://www.luahelena.com.br/ia/?lang=en) · Questions, suggestions, or proposals? Feel free to contact me at [LuaHelenaMMC@gmail.com](mailto:LuaHelenaMMC@gmail.com).
