<!-- SPDX-FileCopyrightText: 2026 Lua Helena Moon Martins Cardoso (Moon) -->
<!-- SPDX-License-Identifier: CC-BY-4.0 -->

# Moon Image Cortex changelog

## 0.1.0-pre.4 — 2026-10-09

- Expanded all eleven specialist engines and six reusable components with detailed operating regimes, source-to-output parameters, prompt construction, realistic examples, failure diagnostics and module-specific QA.
- Strengthened shared visual-state compilation, preservation-first editing, source/reference abstraction and artifact-quality inspection.
- Retained one Visual Director, geography-neutral photography, independently addressable components and existing rights, privacy and renderer boundaries.
- Added tests guarding the depth and discoverability of the enriched public modules; package manifest and complete deterministic ZIP remain synchronized.

## 0.1.0-pre.3 — 2026-10-09

- Made the previously Brazil-specific nostalgic camera route explicitly geography- and era-neutral by default, with eight optional country-context research adapters plus unrestricted custom locations.
- Reorganized visual engines into photography, interfaces and retrofutures, expressive/editorial, and experimental families; organized six shared components by functional responsibility.
- Adopted English-only active names and paths, including **Lived-In Retrofuturism**.
- Expanded context-provenance and anti-stereotyping rules; retained user control over place and actual subjects, with no inferred nationality.
- Updated route index, tests and reproducible ZIP; this is a public routing and structure revision, not measured cultural or rendering fidelity.

## 0.1.0-pre.2 — 2026-10-09

- Corrected specialist-module anatomy: ten active and one experimental engine now have their own addressable public subcontracts.
- Promoted six generalized cross-cutting components, including Omnialchemy, Web Aesthetics, Human Canon Forge, Conservative Photo Edit, Reference Abstraction Guardrail, and Configurable Visual Profile.
- Added an index with selective activation and honest tool/renderer boundaries; the Visual Director remains the sole general operational entry.
- Expanded the portable ZIP to transport the complete component family, with structural tests.
- Preserved consent, third-party permissions and the distinction between instructions and evaluated image outputs.

## 0.1.0-pre.1 — 2026-10-08

- Established Moon Image Cortex as the fourth public Moon Cortex module.
- Published one canonical Visual Director with embedded First Use and truthful renderer states.
- Generalized the shared visual kernel, identity-consent adapter, QA protocols and eleven specialist routes.
- Added 22 synthetic text acceptance intents and text-only examples.
- Added a deterministic complete ZIP and structural/content validation scripts.
- Recorded Pixel-World Camera Translation as experimental and kept reference/image permissions explicit.
- Clarified that the pixel-world translation prototype has only been exercised in a Habbo context, with no cross-game validation, copied assets, or affiliation implied.
- Stated the optional editorial-poster submode’s two-second thesis / ten-second visual-turn reading heuristic as a design target, not a measured guarantee.
- No image rendering, model performance, exact identity fidelity, or external adoption claim is made.


<!-- MOON-CORTEX-PUBLIC-STAMP -->

---

> 🌙 **Moon Cortex** · created by **Lua Helena Moon Martins Cardoso (Moon)** with AI-assisted coauthorial development by **Áurion** · [Licensing](https://github.com/luahelenammc/Moon-Cortex/blob/main/LICENSING.md) · [Moon Source bridge](https://github.com/luahelenammc/Moon-Source) · [Professional context](https://www.luahelena.com.br/ia/?lang=en) · Questions, suggestions, or proposals? Feel free to contact me at [LuaHelenaMMC@gmail.com](mailto:LuaHelenaMMC@gmail.com).
